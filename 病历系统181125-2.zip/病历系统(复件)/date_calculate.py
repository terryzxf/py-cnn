##
# 计算并返回 开始日期间隔次数后的结束日期
def calculate_end_date(startday, dosesplit):
    import arrow as arw
    st = startday   # 开始日期
    T = dosesplit   # 次数
    # test tail
    # T = '29'
    # st = '2018-02-01'

    # test tail
    # print(type(weekend_judge))
    # print ('  weekend_judge:',weekend_judge)
    # print('  T_judge:',T_judge)
    # print('  eval(T):',eval(T))
    # print('  not(isinstance(eval(T),int)):',not(isinstance(eval(T),int)))


    st_date = arw.get(st)
    a = int(T) // 5
    b = int(T) % 5
    # test tail
    # print('   ', st_date.isoweekday())
    if b == 0:
        if st_date.isoweekday() == 1:
            day_shift = (a - 1) * 7 + 5 - 1
        else:
            day_shift = (a - 1) * 7 + 5 + 2 - 1

    elif b == 1:
        day_shift = a * 7 + b - 1

    elif b == 2:
        if st_date.isoweekday() == 5:
            day_shift = a * 7 + b + 2 - 1
        else:
            day_shift = a * 7 + b - 1

    elif b == 3:
        if st_date.isoweekday() == 4 or st_date.isoweekday() == 5:
            day_shift = a * 7 + b + 2 - 1
        else:
            day_shift = a * 7 + b - 1

    elif b == 4:
        if st_date.isoweekday() == 1 or st_date.isoweekday() == 2:
            day_shift = a * 7 + b - 1
        else:
            day_shift = a * 7 + b + 2 - 1
    end_date = st_date.shift(days=day_shift)
    out_enddate = end_date.format('YYYY-MM-DD')
    return out_enddate


    # 'out_enddate' and 'end_date' is the day end oncology without interrupt
    # print('  ', out_enddate)


