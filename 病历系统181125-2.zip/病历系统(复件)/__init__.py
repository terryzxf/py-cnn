
from UI import *

main = Ui_MainWindow()
