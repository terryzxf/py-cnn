

from date_calculate import calculate_end_date
import arrow as arw
st_date = input('  start date(date(YYYY-MM-DD),workdatimes) :')
times = input('  times(number>0,int): ')

weekend_judge = arw.get(st_date).isoweekday() in (6, 7)
T_judge = eval(times) < 0 or not (isinstance(eval(times), int))
while T_judge or weekend_judge:
    if weekend_judge:
        print('   it`s weekend! please input a workdatimes!')
        st_date = input('  start date: ')

    if eval(times) < 0:
        print("  times must above zero and must be 'int':")
        times = input('  times(>0): ')

    if not (isinstance(eval(times), int)):
        print("  times must above zero and must be 'int':")
        times = input("  times(>0,'int'): ")
    T_judge = eval(times) < 0 or not (isinstance(eval(times), int))
    weekend_judge = arw.get(st_date).isoweekday() in (6, 7)
end_date  = calculate_end_date(st_date,times)
print(end_date)