
import date_calculate
from info_get import info_get





def dose_cal(Tdose):

    dose = Tdose.split('/')   # 对TdoseE输入格式 xxGY/yyF 的处理 分割成 [xx,yy]
    tdose = eval(dose[0])      # 首次计划的总剂量
    dosesplit = eval(dose[1]) # 首次计划的次数
    dose_t = tdose/dosesplit  # 单词剂量
    return tdose, dosesplit, dose_t   #返回首次总剂量, 分割次数, 单次剂量




def date_cal(startdate, dosesplit): # 计算出每个病程的日期存入列表

    date = []

    #enddate = calculate_end_date(startdate, dosesplit)  #结束日期

    recNum = dosesplit/5+1

    for i in range(recNum):

        if i == 0:
            date[i] = startdate #初始日期
        else:
            date[i] = calculate_end_date(startdate, 5 * i-1) #每5次的日期
    return date, len(date)      # 返回日期列表 列表长度





def doc_mk(pt_S, beamNum, firmStyle, Tdose, date, diagnosisT, sectNum, Exdose, Ldose):


    import docx
    from docx.enum.text import WD_PARAGRAPH_ALIGNMENT  # 引入文字的位置样式
    from docx.shared import Pt  # 设置字体


        #    需要传入:  病人信息  治疗野数^  固定方式^  医师  总治疗剂量^  date[] 特殊表现({{diagnosisT}})   需要UI支持三个量输入
        #   1.标题生成  done
        #   2.首次病程生成  done
        #   3.计算需要的中间病程数  ing...  计算结束日期OK , 中间记录数= 分割次数/5-2  计算每次日期. date[]
        #   4.生成自动的中间病程    循环实现  特殊表现代入与循环变量挂钩  5, 10, 15, 20, 25, 30, 35,特殊表现( {{ diagnosisT[] }} )
        #   5.文档变量代入  模板变量代入
        #   6.文档保存 文件名 病人姓名_病程.docx
        #   文档实现功能: 文档生成病程记录: 自动实现各个信息变量代入,格式代入,自动保存.

        # info_get()返回 pt_S 为病人信息序列: ['id', 'RTid','Curesta', 'Names', 'sex', 'age', 'Department',
        #                                   'bedNum','dignose', 'phoneNum', 'bodyPart', 'startDate']
        #
        #  ['姓名:', pt_S.Names,       '性别:', pt_S.sex,           '年龄:', str(pt_S.age),
        #   '科室:', pt_S.Department,  '床号:', str(pt_S.bedNum),
        #   '诊断:', pt_S.dignose,     '电话:', str(pt_S.phoneNum), ,
        #   '治疗部位:', str(pt_S.bodyPart),    '开始日期:', str(pt_S.startDate)]
        #
        #   模板文档; 首次病程: X1doc.docx  段落文档: paragraph.docx
        #   需迭代变量:
        # {{startDate}}  --  date[0]^^^             date[]数组构建
        # {{dateN}}          date[n]
        # {{dateL}}          date[L]
        # {{pName}},         pt_S.Names
        # {{sex}},           pt_S.sex
        # {{age}}            pt_S.age
        # {{diagnose}}       pt_S.dignose
        # {{bodyPart}}       pt_S.bodyPart
        # {{confirm}}        firmStyle              固定方式传倒
        # {{beamNum}}        beamNum                野数传到
        # {{Dose}}           Tdose                  剂量推倒分割方式推倒 dose[]构建
        # {{DoseN}}          dose[n]
        # {{DoseL}}          Tdose/ Tdose+Ldose[]   分段模式构建总剂量计算
        # {{doctor}}    --   默认值
        # 内在变量sectNum 治疗分段改野次数
        # 函数传入列表 pt_S, beamNum, firmStyle, Tdose, date, diagnosisT Ldose, sectNum)

        # UI需要构建传入结构: 治疗野数^  固定方式^  总治疗剂量^  开始治疗日期^  分段数  [ Ldose[] ]
        # 野数输入框  固定方式下拉菜单  总剂量输入  开始日期输入框 分段数   根据分段数变化的LDose[]输入框数

    Rectimes = len(date)

    file1 = docx.Document('/home/zxf/病人登记/模板doc/X1doc.docx')



    file2 = docx.Document('/home/zxf/病人登记/模板doc/paragraph.docx')



    doc = docx.Document() #'home/zxf/病人登记/病程记录/'+ pt_S.Names +'_病程记录.docx'  # 新建word文档 
    docTex1 = [paragraph.text for paragraph in file1.paragraphs]
    docTex2 = [paragraph.text for paragraph in file2.paragraphs]



    paragraph1 = doc.add_paragraph()
    #paragraph1.paragragh_format.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    paragraph1.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    title = paragraph1.add_run('病程记录')

    #title = parTitle.add_run()
    title.font.size = Pt(16)
    title.font.bold = True
    # date=['20180101','20180107','20180201','20180301','20180401']

    for n in range(Rectimes):

        if n == 0:

            firstPh = doc.add_paragraph()
            firstPh.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            ad0 = firstPh.add_run(date[n])
            ad0.font.size = Pt(11)

            for j in range(len(docTex1)):

                firstPh = doc.add_paragraph()
                firstPh.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
                ad0 = firstPh.add_run('      '+ docTex1[j])
                ad0.font.size = Pt(11)

            firsts = doc.add_paragraph()
            firsts.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
            ad0s = firsts.add_run('zxf')
            ad0s.font.size = Pt(11)

        elif n>0 and n <Rectimes-1:


            midD = doc.add_paragraph()
            midD.paragraph_format.alignment =WD_PARAGRAPH_ALIGNMENT.LEFT
            ad1D = midD.add_run(date[n])
            ad1D.font.size = Pt(11)

            midPh = doc.add_paragraph()
            midPh.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            ad1 = midPh.add_run('      '+ docTex2[0])
            ad1.font.size = Pt(11)

            mids = doc.add_paragraph()
            mids.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
            ad1s = mids.add_run('zxf')
            ad1s.font.size = Pt(11)

        else:

            endD = doc.add_paragraph()
            endD.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            ad2D = endD.add_run(date[n])
            ad2D.font.size = Pt(11)


            endPh = doc.add_paragraph()
            endPh.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            #ad2 = endPh.add_run(date[n] + '\n')
            ad2 = endPh.add_run('      '+docTex2[1])
            ad2.font.size = Pt(11)

            ends = doc.add_paragraph()
            ends.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
            ad2s = ends.add_run('zxf')
            ad2s.font.size = Pt(11)

    doc.save('/home/zxf/病人登记/病程记录/'+ pt_S.Names +'_病程记录.docx')




pt_S, patient_info, table_tail = info_get.info_get(3000)
print(pt_S)
beamNum = 3
firmStyle = 'U型面膜+体架'
Tdose= '40/20'
date=['20180101','20180107','20180201','20180301','2018041']
diagnosisT = '@@@@@'
sectNum = 2
Exdose ='20/10'
Ldose ='10/5'
doc_mk(pt_S, beamNum, firmStyle, Tdose, date, diagnosisT, sectNum, Exdose, Ldose)




"""
#第一段
paragraph1=file.add_paragraph('病程记录')
paragraph1.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
paragraph1.style='Title'

#第二段
paragraph2=file.add_paragraph()
paragraph2.paragraph_format.alignment=WD_PARAGRAPH_ALIGNMENT.CENTER
L = 'text'
run=paragraph2.add_run(L) #向段落中追加文字
run.bold=True    #设置追加文字样式
run.font.size=Pt(30)
#run.style='Emphasis'

# 第三段
paragraph3=file.add_paragraph()
paragraph3.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
paragraph3.style = 'Normal'
run=paragraph3.add_run('Tomorrow is my birthay.I am looking forword your coming')
run.font.size=Pt(20)
file.save('/home/zxf/病人登记/模板doc/text.docx')
#file.save('/home/zxf/病人登记/模板doc/'+ L +'.docx')
"""

