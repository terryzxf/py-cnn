# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MW_zxf.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
from PyQt5.QtGui import QFont
from info_get import info_get as ptinfo
from PyQt5 import QtCore, QtWidgets #QtGui,
#from PyQt5.QtGui import QIcon
import sys



class Ui_MainWindow(object):

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.infoLbl = QtWidgets.QLabel(self.centralwidget)
        self.infoLbl.setGeometry(QtCore.QRect(10, 10, 561, 111))
        self.infoLbl.setLineWidth(12)
        self.infoLbl.setText("")
        self.infoLbl.setOpenExternalLinks(False)
        self.infoLbl.setObjectName("infoLbl")

        self.TdoseE = QtWidgets.QLineEdit(self.centralwidget)
        self.TdoseE.setGeometry(QtCore.QRect(90, 170, 61, 24))
        #self.TdoseE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.TdoseE.setObjectName("TdoseE")

        self.chkBtn = QtWidgets.QPushButton(self.centralwidget)
        self.chkBtn.setGeometry(QtCore.QRect(680, 20, 89, 24))
        #self.chkBtn.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.chkBtn.setObjectName("chBtn")

        self.rtidEdt = QtWidgets.QLineEdit(self.centralwidget)
        self.rtidEdt.setGeometry(QtCore.QRect(580, 20, 89, 24))
        #self.rtidEdt.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.rtidEdt.setObjectName("rtidEdt")

        self.beamNumE = QtWidgets.QLineEdit(self.centralwidget)
        self.beamNumE.setGeometry(QtCore.QRect(10, 170, 61, 24))
        #self.beamNumE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.beamNumE.setObjectName("beamNumE")

        self.infoTbl = QtWidgets.QTableView(self.centralwidget)
        self.infoTbl.setGeometry(QtCore.QRect(10, 200, 781, 341))
        #self.infoTbl.setFocusPolicy(QtCore.Qt.TabFocus|QtCore.Qt.ClickFocus)
        self.infoTbl.setObjectName("infoTbl")

        self.docBtn = QtWidgets.QPushButton(self.centralwidget)
        self.docBtn.setGeometry(QtCore.QRect(610, 170, 83, 24))
        #self.docBtn.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.docBtn.setObjectName("docBtn")

        self.recBtn = QtWidgets.QPushButton(self.centralwidget)
        self.recBtn.setGeometry(QtCore.QRect(700, 170, 83, 24)
        #self.recBtn.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        #self.recBtn.setObjectName("recBtn")

        self.toolButton = QtWidgets.QToolButton(self.centralwidget)
        self.toolButton.setGeometry(QtCore.QRect(550, 170, 47, 23))
        #self.toolButton.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.toolButton.setObjectName("toolButton")

        self.startDateE = QtWidgets.QLineEdit(self.centralwidget)
        self.startDateE.setGeometry(QtCore.QRect(170, 170, 61, 24)
        #self.startDateE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.startDateE.setObjectName("startDateE")

        self.sectNumE = QtWidgets.QLineEdit(self.centralwidget)
        self.sectNumE.setGeometry(QtCore.QRect(250, 170, 61, 24))
        #self.sectNumE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.sectNumE.setObjectName("sectNumE")

        self.BeamNumlbl = QtWidgets.QLabel(self.centralwidget)
        self.BeamNumlbl.setGeometry(QtCore.QRect(10, 140, 68, 16))

        self.BeamNumlbl.setObjectName("BeamNumlbl")

        self.Tdoselbl = QtWidgets.QLabel(self.centralwidget)
        self.Tdoselbl.setGeometry(QtCore.QRect(100, 140, 68, 16))
        self.Tdoselbl.setObjectName("Tdoselbl")

        self.startDatelbl = QtWidgets.QLabel(self.centralwidget)
        self.startDatelbl.setGeometry(QtCore.QRect(170, 140, 68, 16))
        self.startDatelbl.setObjectName("startDatelbl")

        self.secNumlbl = QtWidgets.QLabel(self.centralwidget)
        self.secNumlbl.setGeometry(QtCore.QRect(250, 140, 68, 16))
        self.secNumlbl.setObjectName("secNumlbl")

        self.firmStyle = QtWidgets.QComboBox(self.centralwidget)
        self.firmStyle.setGeometry(QtCore.QRect(330, 170, 86, 24))
        #self.firmStyle.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.firmStyle.setCurrentText("")
        self.firmStyle.setObjectName("firmStyle")

        self.stylelbl = QtWidgets.QLabel(self.centralwidget)
        self.stylelbl.setGeometry(QtCore.QRect(330, 140, 68, 16))
        self.stylelbl.setObjectName("stylelbl")

        self.ExdoseE = QtWidgets.QLineEdit(self.centralwidget)
        self.ExdoseE.setGeometry(QtCore.QRect(430, 170, 51, 24))
        #self.ExdoseE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.ExdoseE.setObjectName("ExdoseE")

        self.Exdoselbl = QtWidgets.QLabel(self.centralwidget)
        self.Exdoselbl.setGeometry(QtCore.QRect(430, 140, 68, 16))
        self.Exdoselbl.setObjectName("Exdoselbl")

        self.LdoseE = QtWidgets.QLineEdit(self.centralwidget)
        self.LdoseE.setGeometry(QtCore.QRect(490, 170, 51, 24))
        #self.LdoseE.setFocusPolicy(QtCore.Qt.TabFocus | QtCore.Qt.ClickFocus)
        self.LdoseE.setObjectName("LdoseE")

        self.Ldoselbl = QtWidgets.QLabel(self.centralwidget)
        self.Ldoselbl.setGeometry(QtCore.QRect(500, 140, 68, 16))
        self.Ldoselbl.setObjectName("Ldoselbl")

        self.statusbar = QtWidgets.QStatusBar(self.centralwidget)
        self.statusbar.setGeometry(QtCore.QRect(5, 566, 800, 32))
        font =QFont()
        font.setPointSize(20)
        font.setBold(True)
        self.statusbar.setFont(font)
        self.statusbar.setObjectName("statusbar")

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.firmStyle.setCurrentIndex(3)
        self.firmStyle.addItem("U型面膜+体架")
        self.firmStyle.addItem("S型面膜+体架")
        self.firmStyle.addItem("真空负压袋")
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # 信号槽位置
        self.retranslateUi(MainWindow)
        self.chkBtn.clicked.connect(self.chkBtn_Clk)
        self.docBtn.clicked.connect(self.docBtn_Clk)
        self.recBtn.clicked.connect(self.recBtn_Clk)
        self.sectNumE.textEdited.connect(self.sectNumE_endEdt)
        self.beamNumE.textEdited.connect(self.beamNumE_endEdt)
        self.TdoseE.textEdited.connect(self.TdoseE_endEdt)
        self.startDateE.textEdited.connect(self.startDateE_endEdt)

        #self.infoLbl.mouseDoubleClickEvent(self.infoLbl,infoLbl_Clk)

        self.Ldoselbl.setVisible(False)
        self.Exdoselbl.setVisible(False)
        self.ExdoseE.setVisible(False)
        self.LdoseE.setVisible(False)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        #
        MainWindow.setTabOrder(self.rtidEdt, self.chkBtn)
        MainWindow.setTabOrder(self.chkBtn, self.beamNumE)
        MainWindow.setTabOrder(self.TdoseE, self.startDateE)
        MainWindow.setTabOrder(self.sectNumE, self.firmStyle)
        MainWindow.setTabOrder(self.firmStyle, self.docBtn)
        MainWindow.setTabOrder(self.docBtn, self.recBtn)
        MainWindow.setTabOrder(self.recBtn, self.rtidEdt)

    def chkBtn_Clk(self):
            if self.rtidEdt.text() != '':
                rtid = self.rtidEdt.text()  #path = '/home/zxf/病人登记/Data.xlsx'
                pt_S, pt_info, pt_infoTbl= ptinfo.info_get(rtid)
                err = pt_S is None
                self.statusbar.showMessage('查询 %s !' % ('error'if err else rtid ))
                self.infoLbl.setText(pt_info)
            else:
                self.statusbar.showMessage('rdid is null, input again! stupid!')


    # docBtn() 功能:生成病程
    #  子过程:
    # 1.需要完成的动作: BeamNum Tdose startDose secNum firmStyle Exdose Ldose 的获取存储           done
    #   动作 secNum change动作  secNum=2 Exdose Ldose可见  secNum=1 Exdose可见 secNum='' Exdose   done
    # 2.
    def docBtn_Clk(self):
        self.statusbar.showMessage('生成doc!')


    def recBtn_Clk(self):
        self.statusbar.showMessage('生成rec!')

    def sectNumE_endEdt(self): #完成的动作: 检验格式合法性  变量传递 设置追加剂量input 和label的可视性

        secNum = self.sectNumE.text()
        if secNum == '':
            self.Ldoselbl.setVisible(False)
            self.Exdoselbl.setVisible(False)
            self.ExdoseE.setVisible(False)
            self.LdoseE.setVisible(False)
        elif secNum == '1':
            self.Ldoselbl.setVisible(False)
            self.Exdoselbl.setVisible(True)
            self.ExdoseE.setVisible(True)
            self.LdoseE.setVisible(False)
        elif secNum == '2':
            self.Ldoselbl.setVisible(True)
            self.Exdoselbl.setVisible(True)
            self.ExdoseE.setVisible(True)
            self.LdoseE.setVisible(True)
        else:
            self.Ldoselbl.setVisible(False)
            self.Exdoselbl.setVisible(False)
            self.ExdoseE.setVisible(False)
            self.LdoseE.setVisible(False)
            self.ExdoseE.setVisible(False)
            self.LdoseE.setVisible(False)
            self.statusbar.showMessage("secNum get an unexpect input, check ur mind.")

    def beamNumE_endEdt(self): #完成的动作: 检验格式合法性  变量传递

        beamNum = self.beamNumE.text()
        if not eval(beamNum).isalnum() and int(beamNum) in range (15):
            self.statusbar.showMessage("!!! (BeaNu) illegal input !!!")




    def TdoseE_endEdt(self): #完成的动作: 检验格式合法性  变量传递

        Tdose = self.TdoseE.text()

    def startDateE_endEdt(self): #完成的动作: 检验格式合法性  变量传递

        startDate = self.startDateE.text()



    def retranslateUi(self, MainWindow):

        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Soul"))
        self.chkBtn.setText(_translate("MainWindow", "OK"))
        self.docBtn.setText(_translate("MainWindow", "DM"))
        self.recBtn.setText(_translate("MainWindow", "BM"))
        self.toolButton.setText(_translate("MainWindow", "..."))
        self.BeamNumlbl.setText(_translate("MainWindow", "BeaNu"))
        self.Tdoselbl.setText(_translate("MainWindow", "Tdo(G/F)"))
        self.startDatelbl.setText(_translate("MainWindow", "StD(Y4M2D2)"))
        self.secNumlbl.setText(_translate("MainWindow", "sec"))
        self.stylelbl.setText(_translate("MainWindow", "style"))
        self.Exdoselbl.setText(_translate("MainWindow", "Ed(G/F)"))
        self.Ldoselbl.setText(_translate("MainWindow", "Ld(G/F)"))


    def __init__(self):
        super().__init__()

        app = QtWidgets.QApplication(sys.argv)
        MainWindow = QtWidgets.QMainWindow()
        #ui = Ui_MainWindow()
        self.setupUi(MainWindow)
        #MainWindow.setWindowIcon(QIcon('icon.png'))  #增加icon图标
        MainWindow.show()
        sys.exit(app.exec_())

"""
if __name__ == "__main__":


    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    #MainWindow.setWindowIcon(QIcon('icon.png'))  #增加icon图标
    MainWindow.show()
    sys.exit(app.exec_())
"""