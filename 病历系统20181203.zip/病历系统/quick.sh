#!/bin/bash
/home/zxf/anaconda3/bin/python /home/zxf/PycharmProjects/test/zxf/病历系统/__init__.py
