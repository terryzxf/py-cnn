#!/usr/bin/env python3
from UI import *

main = Ui_MainWindow()
